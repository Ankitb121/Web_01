import { motion } from 'motion/react';

export default function PrivacyPolicyPage() {
  return (
    <div className="pt-32 pb-16 bg-white min-h-screen">
      <section className="relative py-20 bg-gray-900 text-white overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,#c41e1e_0%,transparent_70%)] opacity-20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-3xl md:text-4xl font-extrabold mb-4 tracking-tight leading-tight uppercase">
              Privacy <span className="text-[#c41e1e]">Policy</span>
            </h1>
          </motion.div>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg max-w-none text-gray-600">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 uppercase">Cell Phone Repair® Online Privacy Notice</h2>
            <p className="mb-6">
              This Online Privacy Notice (“Notice”) applies to this website (“Website” or “Site”) owned and operated by Lookout Point LLC, and its affiliated companies (“Companies”). This Notice does not apply to any website or service that does not display this Notice. This Notice does not apply to information collected or received apart from this Site and does not apply to data that does not allow us or third parties to identify or contact you. The Companies collection and use of your information may be subject to laws and additional notices which may limit the Companies’ use of your information or provide you with rights that are not described in this Notice.
            </p>
            <p className="mb-6">
              We use the brand name “Cellphone Repair” to associate our products and services and to connect us with the brand Lookout Point LLC. This Notice is intended to inform user of this website our practices with regard to personal information collected through this website. As used in this online Privacy Notice, the term “you and your” are defined to include all website visitors including, but not limited to, customers, brokers, third party administrators, and/or representatives of any of the above.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Information We Collect</h3>
            <p className="mb-4"><strong>Information You Provide Us.</strong> We collect and retain any information provided by you or gathered from your interaction with this website. For instance, we collect information when you send us an email to one of our online email boxes, or by completing a form and either sending it to us directly, submitting it through the Site or by logging onto the Site.</p>
            <p className="mb-4">The information we collect may consist of the following:</p>
            <ul className="list-disc pl-6 mb-6">
              <li>First and Last name</li>
              <li>Physical address, including zip code</li>
              <li>Mobile Number</li>
              <li>Email address</li>
            </ul>
            <p className="mb-6">
              You may choose not to provide personal information to us by not sending us an email using our online email boxes, by not filling out a form with personal information and/or by not logging onto our website. Refer to the last section for other ways to contact us.
            </p>

            <p className="mb-4"><strong>Device and Web Browsing Information.</strong> We may collect information from your devices and about your web browsing when you visit our Site. We may collect information such as:</p>
            <ul className="list-disc pl-6 mb-6">
              <li>Your IP address</li>
              <li>The type of browser, devices and operating systems you use</li>
              <li>Identifiers associated with the device(s) you use to access our Site</li>
              <li>The pages you visit and the features you use, including dates and times</li>
              <li>If you navigated from or navigate to another website, the address of that website</li>
              <li>Information regarding your internet service provider</li>
            </ul>

            <p className="mb-4"><strong>Data Analytics.</strong> The Companies use cookies, a small file placed on your computer, or similar technologies to analyze trends, administer the Site, track users’ movements around the Site, and to gather information about our user base as a whole. In addition, we may collect information about your activities on our Site through the use of cookies, clear GIFs or web beacons, local shared objects or Flash cookies, or through other identifiers or technologies, including similar technologies as they may evolve over time. We refer to these technologies collectively as “Tracking Technologies”. The information that we and our third party service providers track with cookies may include, but is not limited to, the type of browser (such as Google Chrome or Internet Explorer) and Internet-connected devices being used to access the Site, your Internet protocol (“IP”) address, your home domain or Internet service provider, your referrer URL (which is the URL for the website that you were viewing prior to visiting the Site), how you were directed to the Site, which specific pages you access on the Site, how long you view each page, the time and date you access our Site and the total number of visitors to the Site and any portions thereof. We, and/or our third-party service providers, may use the information collected from cookies or similar files on your computer for security purposes (such as authentication), to facilitate Site navigation and to personalize your experience while visiting the Site.</p>

            <p className="mb-4"><strong>Google® Analytics and Web Beacons.</strong> Our websites may use Google Analytics, a web analysis service provided by Google, in order to better understand your use of our Site and how we can improve them. Google Analytics collects information such as how often users visit a website, what pages you visit when you do so, and what other websites you used prior to coming to such website. Google Analytics collects only the IP address assigned to you on the date you visit a website, rather than your name or other identifying information. We do not combine the information collected through the use of Google Analytics with your information. Although Google Analytics plants a permanent cookie on your web browser to identify you as a unique user the next time you visit a website, the cookie cannot be used by anyone but Google. Google’s ability to use and share information collected by Google Analytics about your visits to the Site is restricted by the Google Analytics Terms of Use and the Google Privacy Policy. Google utilizes the data collected to track and examine the use of the Site, to prepare reports on its activities and share them with other Google services. Google may use the data collected on the Site to contextualize and personalize the ads of its own advertising network. To more fully understand how Google may use the data it collects on the Site, please review “How Google uses data when you use our partners’ sites or apps,” (located here).</p>
            <p className="mb-6">Some of the areas of the Site may contain electronic images known as web beacons (sometimes known as clear gifs) that allow Lookout Point LLC to count and track users who have visited certain portions of the Site</p>

            <p className="mb-6"><strong>Email.</strong> We may collect information regarding the effectiveness of our email and other communications with you. For example, we may know if you follow a link in an email we send to you.</p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">How we use your information</h3>
            <p className="mb-6">
              The information described above may be used to provide those services you have requested. It may also be used to help us assist you with technical issues encountered when using our website and to improve our website – make your visits more appealing. The information you provide may also be used by us to meet our legal and regulatory obligations, and industry standards and best practices, including but not limited to conducting business screenings.
            </p>
            <p className="mb-6">
              If you choose to provide us with personal information, such as in an email to one of our online email boxes, by filling out a form with your personal information and submitting it to us through our website or by logging onto our website, we use that information to respond to your message and to help us provide you with the information you have requested. We use information provided in order to process transactions that you request and to authenticate you as a registered user.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">How We Share Your Information</h3>
            <p className="mb-6">
              We do not sell or rent information collected through the Site. We will use and disclose the information you give us only as indicated above or as required and permitted by law. This may include, for example, disclosures to third parties that perform business services on our behalf or in response to a request from a law enforcement agency or subpoena.
            </p>
            <p className="mb-4">We may share the information we gather, including as follows:</p>
            <ul className="list-disc pl-6 mb-6">
              <li><strong>Service Providers.</strong> We may share information with third-party service providers and others who help us operate our business or provide services on our behalf. These service providers include credit bureaus, those who may help us verify identities and backgrounds, those who help us handle your account or provide customer service, and data analytics companies and others that provide services on our Sites.</li>
              <li><strong>Corporate Affiliates and Other Ventures.</strong> We may share information with our corporate affiliates for their everyday business purposes, to provide services or to perform marketing. We may also participate in joint ventures with others and we may share information as part of that joint venture.</li>
              <li><strong>Regulators.</strong> We may share information with regulators, including as necessary to comply with regulatory oversight of our businesses.</li>
              <li><strong>Promotional.</strong> We may share information with third parties who help us develop and promote products and services, including joint marketing, or to help us customize advertisements, offers, or other communications to you.</li>
              <li><strong>Business Transfer.</strong> We may share information we have collected from you in connection with the sale or merger of our business or the transfer of assets, you will be notified via email and/or a prominent notice on our website, of any change in ownership, uses of your personal information, and choices you may have regarding your personal information.</li>
              <li><strong>Protection of Ourselves and Others.</strong> We may use and share the information we gather to protect our own and others’ rights and property, including protection of our affiliates, customers and members of the public. We may use and share the information we gather to comply with applicable law, legal process (such as in a response to a subpoena or court order), legal advice and for preventing fraud, theft, and injury to you, us or others.</li>
            </ul>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Email Communication</h3>
            <p className="mb-6">
              Please do not use email to communicate information to us that you consider confidential. Email is not a secure method of communication and is not encrypted. Accordingly, an email message potentially could be accessed and viewed by others without your knowledge and/or permission, while in transit to us.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Process for Reviewing or Requesting Changes to Personal Information</h3>
            <p className="mb-6">
              If you think that any personal information we have collected about you is inaccurate, you may send a written request for review to us at the address provided below. We will investigate your request and make appropriate changes if warranted.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Changes to this Policy</h3>
            <p className="mb-6">
              We may update this Privacy Notice from time to time and suggest that you review it each time you access and use the Service. Please review changes carefully. If any changes are made to this Privacy Notice, we will revise the Effective Date that is indicated at the bottom of it.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Links to other Websites</h3>
            <p className="mb-6">
              This website may contain links to other websites that may have online information practices different from ours. We are not responsible for the privacy and security practices of those websites, and we encourage our visitors to learn about the privacy and security practices of those websites.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Children</h3>
            <p className="mb-6">
              We do not knowingly collect personal information from anyone under the age of 13. For more information about protecting your child’s privacy online, visit the Federal Trade Commission.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Privacy Contact Information</h3>
            <p className="mb-6">
              We welcome your questions or comments regarding this Notice. Please write to Us at Lookout Point LLC Office, 835 NE Green Oaks Blvd Suite B, Arlington, TX, United States, Texas or send Us an email at cprepair0@gmail.com.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
