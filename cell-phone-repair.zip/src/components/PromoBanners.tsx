import { motion } from 'motion/react';

export default function PromoBanners() {
  return (
    <section className="py-20 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Section */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl lg:text-5xl font-extrabold text-gray-900 mb-4 tracking-tight uppercase">
              SERVICE YOU CAN <span className="text-[#c41e1e]">TRUST</span>
            </h2>
            <div className="w-24 h-1.5 bg-[#c41e1e] mx-auto rounded-full"></div>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Repair Panel */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="relative bg-[#f8fafc] rounded-[40px] overflow-hidden min-h-[500px] flex flex-col p-10 lg:p-14 border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
          >
            {/* Background Image Overlay */}
            <div className="absolute inset-0 w-full h-full pointer-events-none overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1601524909162-4f748d8ceb7c?q=80&w=2000&auto=format&fit=crop"
                alt="Phone Internals and Tools"
                className="w-full h-full object-cover opacity-25 mix-blend-multiply"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="relative z-10 max-w-md">
              <span className="text-[#c41e1e] text-sm font-bold tracking-widest uppercase mb-6 block">
                EXPERT REPAIRS
              </span>
              <h3 className="text-3xl lg:text-4xl font-extrabold text-gray-900 mb-6 leading-tight">
                Professional Device Repair
              </h3>
              <p className="text-gray-600 text-lg mb-8 leading-relaxed">
                From cracked screens to battery replacements, our certified technicians fix your devices quickly with high-quality parts.
              </p>
              <button className="bg-[#e31837] hover:bg-[#c41e1e] text-white font-bold py-2 px-6 rounded-full transition-all text-xs uppercase tracking-wider">
                Learn More
              </button>
            </div>
          </motion.div>

          {/* Buy Sell Trade Panel */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            viewport={{ once: true }}
            className="relative bg-[#1e293b] rounded-[40px] overflow-hidden min-h-[500px] flex flex-col p-10 lg:p-14 shadow-sm hover:shadow-md transition-shadow"
          >
            {/* Background Image Overlay */}
            <div className="absolute inset-0 w-full h-full pointer-events-none overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1556656793-062ff9878258?q=80&w=2000&auto=format&fit=crop"
                alt="Smartphones Collection"
                className="w-full h-full object-cover opacity-30 mix-blend-overlay"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="relative z-10 max-w-md">
              <span className="text-gray-300 text-sm font-bold tracking-widest uppercase mb-6 block">
                MARKETPLACE
              </span>
              <h3 className="text-3xl lg:text-4xl font-extrabold text-white mb-6 leading-tight">
                Buy, Sell & Trade
              </h3>
              <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                Upgrade your tech today. We buy your used devices for cash or credit, and offer certified pre-owned phones at great prices.
              </p>
              <button className="bg-[#e31837] hover:bg-[#c41e1e] text-white font-bold py-2 px-6 rounded-full transition-all text-xs uppercase tracking-wider">
                Learn More
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
