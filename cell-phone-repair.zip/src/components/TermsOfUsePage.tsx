import { motion } from 'motion/react';

export default function TermsOfUsePage() {
  return (
    <div className="pt-32 pb-16 bg-white min-h-screen">
      <section className="relative py-20 bg-gray-900 text-white overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,#c41e1e_0%,transparent_70%)] opacity-20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-3xl md:text-4xl font-extrabold mb-4 tracking-tight leading-tight uppercase">
              Terms <span className="text-[#c41e1e]">Of Use</span>
            </h1>
          </motion.div>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg max-w-none text-gray-600">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 uppercase">Terms of Use</h2>
            <p className="mb-6">
              Welcome to Cell Phone Repair! You may use the website, services, content, technologies and applications of cellphonerepair.com (the “Website”) BY USING THE WEBSITE AND/OR BY CREATING AN ACCOUNT WITH Lookout Point LLC, YOU AGREE TO THE TERMS AND CONDITIONS BELOW, AND ANY SUBSEQUENT MODIFICATIONS THERETO. IF YOU DO NOT AGREE TO THE FOREGOING, DO NOT USE THIS WEBSITE OR OUR SERVICES IN ANY WAY.
            </p>
            
            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Site Terms</h3>
            <p className="mb-6">
              The Website is a service made available by Lookout Point LLC, LP (hereinafter referred to as “Lookout Point LLC”) (“we”, “our” or “us”). The Site Terms govern your use of the Website. We may modify the Site Terms at any time. Your continued use of the Website constitutes your acceptance to all terms and conditions of the Website or our Services at the time of use. Every time you visit the Website, you reaffirm your acceptance of the Site Terms. Upon each visit, you are responsible for reviewing the Site Terms and any additional terms and conditions.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">About the Website</h3>
            <p className="mb-6">
              The Website gives users the ability to buy certain electronic devices such as mobile phones, tablets, and headphones (collectively, the “Device”) subject to these Site Terms. You agree that all transactions will be performed electronically and that the terms of any purchase of any Device will be governed by Lookout Point LLC’s Terms of Sale Agreement located below. We may, in our sole discretion, change or discontinue any or all aspects of the Website at any time, without notice, and without incurring any liability.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Use of the Website</h3>
            <p className="mb-6">
              You may visit the Website without creating an account, however, you must create a MyWiT account if you desire to use any of our services. You further agree to provide accurate, complete information when creating your account and you will notify us of any updates to the information provided by you prior to completing any transactions at phonerepairhust@gmail.com. In order to create a valid account, you must be legally capable to enter into binding contracts. Each account is for your individual use only, unless you have applied for and been qualified by us as a reseller. If your account has been used by someone other than you, you agree to notify us immediately at phonerepairhust@gmail.com All transactions are electronic and governed by our Terms of Sale. We may modify or terminate this Website at any time.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Content Ownership</h3>
            <p className="mb-6">
              The Website contains information, content or advertisements text, photographs, designs, graphics, images, sound and video recordings, animation and other materials and effects (collectively, the “Content”) that are considered intellectual property protected by copyright, trademark, service mark, trade dress, patent or other proprietary right owned by Lookout Point LLC, or other third parties. All Content on the Website is the property of its respective owner/s. Further, Lookout Point LLC or other third parties retain all rights (including intellectual property rights), title and interest in the Website, technology, and all underlying technology and data including any enhancements, software, applications and improvements related to the Website (the “Technology”) (the terms Content and Technology collectively will be referred to as the “Materials”). You may not remove from any electronic or printed copy any copyright, trademark, or other proprietary notice.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Website Prohibitions</h3>
            <p className="mb-4">Lookout Point LLC provides the Website, related Content and the Materials for your individual, non-commercial use and for the purpose of carrying out transactions with the Website. Any other use of the Website or the Materials is strictly prohibited. You may not, either directly or indirectly:</p>
            <ul className="list-disc pl-6 mb-6">
              <li>Sell, modify, license, publish, delete or cache by proxy the Website, Materials or Content without the express written permission of Lookout Point LLC or the applicable rights holder;</li>
              <li>Use the Materials or Content for commercial use in any way;</li>
              <li>Reverse-engineer, decompile, disassemble, merge, copy, use, disclose, rent, lease, loan, sell, sublicense or transfer the underlying source code or structure or sequence of the Technology;</li>
              <li>Use any software to extract information about the Website, usage, or users;</li>
              <li>Reformat any portion of the Website, Materials or Content;</li>
              <li>Use any device, software or routine that interferes with the proper working of the Website, or otherwise attempt to interfere with the proper working of the Website;</li>
              <li>Take any action that puts unreasonably large strain on our system;</li>
              <li>Violate the Site Terms, applicable laws or the rights of others; or interfere with, or violate the legal rights of others; or</li>
              <li>Disrupt, cause harm to, interfere with, or modify the strength of the security of the Website.</li>
            </ul>
            <p className="mb-6">
              You agree that the Website and its Content shall not be used for any illegal or harmful purpose. The lawful remedies available to us include limiting, suspending, terminating or prohibiting access to and use of the Website, its Content, and our services at any time, with or without notice to you. In our sole discretion, we may also remove content, or take technical and legal steps to keep you off the Website if we think that you are creating problems, possible legal liabilities, you are violating any of these terms, or acting inconsistently with the letter or spirit of our policies.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">License</h3>
            <p className="mb-6">
              By using the Website, uploading content to or submitting any materials for use on the Website, you grant (or warrant that the owner of such rights has expressly granted) Lookout Point LLC a perpetual, royalty-free, irrevocable, non-exclusive right and license to use, reproduce, modify, adapt, publish, translate, create derivative works from and distribute such materials and/or information generated through use of the Website or incorporate such materials and/or information generated through use of the Website into any form, medium, or technology now known or later developed throughout the universe.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Automated Activity</h3>
            <p className="mb-6">
              The Website may use robot exclusion methods, which include robots.txt files and HTML meta tags, that expressly allow and/or exclude specified automated programs from accessing certain portions of the Website. Much of the information on the Website is updated on a real-time basis and is proprietary or is licensed to Lookout Point LLC by our users or third parties. You agree that you will not use any robot, spider, scraper or other automated means to access the Website for any purpose, including but not limited to performing “offline” searches and mirroring, without our express written permission as indicated in the then current robots.txt file or HTML meta tags on the Website. Additionally, you agree that you will not bypass our robot exclusion methods or other measures we may use to prevent or restrict access to the Website.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Linking</h3>
            <p className="mb-6">
              You may provide a link to the homepage of this Website, provided you give notice to us of such link by sending an e-mail to phonerepairhust@gmail.com. You must remove any link to this Website should we advise you to within our sole discretion.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Representations</h3>
            <p className="mb-6">
              You represent and warrant to us that (a) you are legally capable to enter into contracts, (b) you are providing us at all times true, accurate and up to date information about yourself, (c) you will comply at all times with the Site Terms and applicable law and (d) your use of the Website and any transactions that you make with us will not violate the rights of any third party.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Disclaimer</h3>
            <p className="mb-6">
              You understand that Lookout Point LLC makes every reasonable effort to ensure the information and Content presented on this Website is accurate and updated and agree Lookout Point LLC does not warrant, represent, or guarantee, express or implied, statutory or otherwise, the accuracy of the information or Content on this Website, makes no guarantee as to such information and is not responsible for the information, including its accuracy, currency, content, quality, compliance or legality, or any resulting loss or damage to you.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Warranty and Liability</h3>
            <p className="mb-6">
              Lookout Point LLC makes no representations regarding the availability and performance of this Website. You understand and agree that any use of or reliance upon this Website or Materials is at your sole risk. We are not responsible for any resulting loss or damages to you.
            </p>
            <p className="mb-6 font-bold">
              THE WEBSITE AND MATERIALS ARE PROVIDED BY Lookout Point LLC ON AN “AS IS” BASIS AND AS AVAILABLE, WITHOUT ANY WARRANTY OR REPRESENTATION OF ANY KIND, WHETHER EXPRESS, IMPLIED, STATUTORY OR OTHERWISE. TO THE FULLEST LAWFUL EXTENT, Lookout Point LLC EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY, ACCURACY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT AND THE IMPLIED CONDITIONS OF SATISFACTORY QUALITY AND ACCEPTANCE AS WELL AS ANY LOCAL JURISDICTIONAL ANALOGUES TO THE ABOVE AND OTHER IMPLIED OR STATUTORY WARRANTIES. WE MAKE NO REPRESENTATIONS THAT THE WEBSITE OR MATERIALS WILL MEET YOUR REQUIREMENTS AND WE DO NOT GUARANTEE THAT ANY CONTENT, INFORMATION, SOFTWARE OR OTHER MATERIAL ACCESSIBLE THROUGH THE WEBSITE WILL BE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS.
            </p>
            <p className="mb-6 font-bold">
              TO THE FULLEST LAWFUL EXTENT, IN NO EVENT SHALL Lookout Point LLC, OR ITS DIRECTORS, OFFICERS, EMPLOYEES, AFFILIATES, AGENTS, DISTRIBUTORS OR CONTRACTORS (HEREINAFTER COLLECTIVELY REFERRED TO AS “Lookout Point LLC” PARTIES”)BE LIABLE FOR ANY COMPENSATORY, INDIRECT, INCIDENTAL, CONSEQUENTIAL OR SPECIAL DAMAGES, LOSS OF DATA, INCOME OR PROFIT, LOSS OF OR DAMAGE TO PROPERTY, OR ANY CLAIMS OF YOU OR OTHER THIRD PARTIES WHATSOEVER WITH RESPECT TO THE WEBSITE OR THE MATERIALS REGARDLESS OF THE LEGAL THEORY ON WHICH THE CLAIM IS BASED, WHETHER BASED IN CONTRACT, TORT, NEGLIGENCE, WARRANTY, OR OTHERWISE, EVEN IF WE HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW, Lookout Point LLC AND THE Lookout Point LLC PARTIES SHALL NOT BE LIABLE FOR ANY LOSSES OR DAMAGES WHATSOEVER RESULTING FROM ANY EVENTS BEYOND OUR REASONABLE CONTROL, INCLUDING BUT NOT LIMITED TO, FAILURE OF THE INTERNET OR ANY VIRUS, DELAY OR INTERRUPTION IN OPERATION OR SERVICE OR FAILURE OF PERFORMANCE, WHETHER RESULTING FROM AN ACT OF GOD, COMMUNICATIONS FAILURE, THEFT OR OTHERWISE. ANY USE OR DERIVATIVE USE OF THIS WEBSITE, ITS CONTENT, OR OUR SERVICES IS AT YOUR SOLE RISK AND LIABILITY. TO THE FULLEST LAWFUL EXTENT, IN NO EVENT SHALL THE MAXIMUM AGGREGATE LIABILITY OF Lookout Point LLC PARTIES ENUMERATED ABOVE, EXCEED THE GREATER OF (I) THE AMOUNT PAID, IF ANY, BY YOU TO US OR (II) $100 FOR DAMAGES ARISING OUT OF THE USE OR DERIVATIVE USE OF THIS WEBSITE, ITS CONTENT, OR OUR SERVICES.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Indemnity</h3>
            <p className="mb-6">
              You agree to indemnify, defend, and hold harmless Lookout Point LLC from and against all claims, liabilities, damages, losses, costs, expenses, or fees (including reasonable attorneys’ fees) that such parties may incur as a result of or arising from your violation or breach of any representation or obligation under these Site Terms. We reserve the right to assume the exclusive defense and control of any matter otherwise subject to indemnification by you and, in such case, you agree to fully cooperate with our defense of such claim. You further agree to fully assist in the defense of any litigation, including pre- litigation and investigation.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Privacy</h3>
            <p className="mb-6">
              Please refer to our Privacy Policy for complete information on our collection and use of personal information and data.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Consent to Electronic Records and Transactions</h3>
            <p className="mb-6">
              In order to use the Website, our services, or open an account with us, you consent to do business with us electronically and to receive information electronically. If you do not agree to the terms of this consent, do not continue to use this Website, our services, or create an account with us. “Communication” means any communication, transaction, notice, disclosure, terms, conditions, agreement, record, statement, advertisement, or other information that we provide to you, or that we ask you to provide to us. With regard to the federal Electronic Signatures in Global and National Commerce Act (E-SIGN), you agree to do business and to enter into contracts with us electronically and to engage in electronic transactions with us, to receive and to provide Electronic Records as defined in E-SIGN, and to use electronic sounds, symbols, or processes as an electronic signature signifying your intent to be bound.
            </p>
            <p className="mb-6">
              You further agree that Electronic Records will be sufficient as “writings” under applicable law or regulation. Your consent to the receipt, provision, use, and exchange of Electronic Records applies not only to the particular transaction with respect to which you are accepting this Consent, but also to all future Communications.
            </p>
            <p className="mb-6">
              You authorize us to send you important notices about the Website and any pending transactions to an email address you provide to us, if you are a registered account holder or, in the alternative, by posting a notice on the Website. You agree to keep your email address up to date and to maintain a valid email address and to ensure that emails we send you are not filtered or stopped by spam filters. If you no longer desire to transact electronically with us, you may no longer use the Website.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Carrier Fees</h3>
            <p className="mb-6">
              You are responsible for all fees that your carrier may charge you for data, text messaging, roaming and other wireless access or communications services that you utilize in order to access, operate, or communicate with this Website.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Notice Regarding Technology</h3>
            <p className="mb-6">
              Lookout Point LLC’s Technology, including any software or applications we provide to you, is a “commercial item,” as that term is defined in 48 C.F.R. 2.101, consisting of “commercial computer software” and “commercial computer software documentation,” as such terms are used in 48 C.F.R. 12.212. Consistent with 48 C.F.R. 12.212 and 48 C.F.R. 227.7202-1 through 227.7202-4, all U.S. Government end users acquire the software with only those rights set forth herein.
            </p>
            <p className="mb-6">
              Your use of the Website must comply with all applicable laws in the territory in which you access and use the Website, including without limitation, all import and export control laws and regulations of the United States and other countries. You must not transfer, by electronic transmission or otherwise, any content, data, or software subject to restrictions under such laws to a national destination, person, or entity or for an end-use prohibited under those laws without first obtaining and complying with government authorization.
            </p>

            <h3 className="text-xl font-bold text-gray-900 mb-4 uppercase">Violations of Site Terms</h3>
            <p className="mb-6">
              Lookout Point LLC reserves the right to investigate complaints or reported violations of the Site Terms and to take any action Lookout Point LLC deems appropriate including but not limited to reporting any suspected unlawful activity to law enforcement officials, regulators, or other third parties and disclosing any information necessary or appropriate to such persons or entities relating to user profiles, e-mail addresses, usage history, posted materials, IP addresses, traffic information and any other such data we have acquired from you. Lookout Point LLC reserves the right to seek all remedies available at law and in equity for violations of these Site Terms. These Site Terms incorporate by reference any agreements contained on the Website and constitutes the entire agreement with respect to access to and use of the Website. If any provision of these Site Terms is unlawful, void or unenforceable then that provision shall be deemed severable from the remaining provisions and shall not affect their validity and enforceability. THESE SITE TERMS SHALL BE GOVERNED BY AND CONSTRUED IN ACCORDANCE WITH THE LAWS OF THE STATE OF TEXAS WITHOUT REGARD TO CONFLICT OF LAW RULES OR PRINCIPLES THAT WOULD CAUSE THE APPLICATION OF LAWS OF ANY OTHER JURISDICTION. YOU IRREVOCABLY CONSENT AND WAIVE ALL OBJECTION TO PERSONAL JURISDICTION AND VENUE AND SUBMIT TO THE EXCLUSIVE JURIDICTION OF THE UNITED STATES DISTRICT COURT FOR THE NORTHERN DISTRICT OF TEXAS AND THE STATE COURTS LOCATED WITHIN COBB COUNTY, TEXAS, USA, AND YOU SHALL NOT COMMENCE OR PROSECUTE ANY SUIT OR ACTION EXCEPT IN THE FOREGOING COURTS.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
